package com.example.pinkphone;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.Minecraft;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;

public class PhoneScreen extends Screen {
    private String app = "home";
    private int page = 0;
    private int horrorStep = 0;
    private int fear = 0;
    private boolean flashlight = false;
    private static final ResourceLocation WALLPAPER = ResourceLocation.fromNamespaceAndPath("pinkphone", "textures/gui/wallpaper_sunset.png");
    private static final ResourceLocation HORROR_HALL = ResourceLocation.fromNamespaceAndPath("pinkphone", "textures/gui/horror_hall.png");
    private static final ResourceLocation HORROR_MONSTER = ResourceLocation.fromNamespaceAndPath("pinkphone", "textures/gui/horror_monster.png");

    private int left, top;
    private float uiScale = 1.0f;
    private int gameTicks = 0;
    private int steps = 0;
    private boolean gameOver = false;
    private boolean won = false;
    // LAST STAND: first-person zombie shooter rendered with crisp, animated pixel-art primitives.
    private int playerX = 73, playerY = 139;
    private int cameraStrafe = 0;
    private int weaponKick = 0;
    private int walkBob = 0;
    private int damageVignette = 0;
    private int hp = 100, ammo = 12, reserveAmmo = 48, kills = 0, wave = 1;
    private int shotFlash = 0, hitFlash = 0, reloadTicks = 0, spawnTicks = 0;
    private int[] enemyX = new int[8], enemyY = new int[8], enemyHp = new int[8];
    private int[] enemyAttack = new int[8];
    private boolean[] enemyAlive = new boolean[8];
    private int aimX = 73, aimY = 80;
    private int battery = 100;
    // Functional phone apps
    private String noteText = "Remember the stars";
    private boolean musicPlaying = false;
    private int musicTrack = 0;
    private static final SoundEvent[] MUSIC_DISC_SOUNDS = {
        SoundEvents.MUSIC_DISC_CAT, SoundEvents.MUSIC_DISC_OTHERSIDE,
        SoundEvents.MUSIC_DISC_PIGSTEP, SoundEvents.MUSIC_DISC_MALL,
        SoundEvents.MUSIC_DISC_CHIRP, SoundEvents.MUSIC_DISC_WAIT
    };
    private static final String[] MUSIC_DISC_NAMES = {"Cat", "Otherside", "Pigstep", "Mall", "Chirp", "Wait"};
    private int gardenWater = 0;
    private int photoIndex = 0;
    private int photosTaken = 0;
    private boolean notifications = true;
    private boolean soundEnabled = true;
    private int wallpaperIndex = 0;
    private boolean notesEditing = false;
    private int animationTick = 0;
    private int scareFlash = 0;
    private static final int PINK = 0xFFF18BB9;
    private static final int LIGHT = 0xFFFFD5E6;
    private static final int PALE = 0xFFFFEEF5;
    private static final int DARK = 0xFF302943;
    private static final int PURPLE = 0xFF66558D;
    private static final int SHADOW = 0xFFB85F8B;
    private static final int WHITE = 0xFFFFF9FC;

    public PhoneScreen() {
        super(Component.literal("Pink Phone"));
    }

    @Override
    protected void init() {
        // Use INTEGER scaling only. Fractional pose scales (for example 1.37x)
        // make pixel art and small font edges look soft in Minecraft.
        // The phone's logical canvas is 178x230; 2x is used only when it fits.
        boolean canUse2x = this.width >= 178 * 2 + 16 && this.height >= 230 * 2 + 16;
        uiScale = canUse2x ? 2.0f : 1.0f;
        left = -87;
        top = -112;
    }

    @Override
    public void tick() {
        super.tick();
        animationTick++;
        if (scareFlash > 0) scareFlash--;
        if (app.equals("battle") && !gameOver && !won) {
            if (shotFlash > 0) shotFlash--;
            if (hitFlash > 0) hitFlash--;
            if (weaponKick > 0) weaponKick--;
            if (damageVignette > 0) damageVignette--;
            if (reloadTicks > 0 && --reloadTicks == 0) {
                int need = 12 - ammo;
                int take = Math.min(need, reserveAmmo);
                ammo += take; reserveAmmo -= take;
            }
            spawnTicks++;
            if (spawnTicks >= Math.max(16, 46 - wave * 3)) {
                spawnTicks = 0;
                for (int i=0;i<enemyAlive.length;i++) if (!enemyAlive[i]) {
                    enemyAlive[i] = true; enemyHp[i] = wave >= 4 ? 2 : 1;
                    enemyX[i] = 24 + Math.floorMod(animationTick * 13 + i * 37, 94);
                    enemyY[i] = 75 + Math.floorMod(animationTick * 3 + i * 19, 38); // depth: larger is closer
                    enemyAttack[i] = 0;
                    break;
                }
            }
            for (int i=0;i<enemyAlive.length;i++) if (enemyAlive[i]) {
                // Zombies advance toward the camera. Their lateral drift makes the lane feel alive.
                if ((animationTick + i) % Math.max(2, 5 - Math.min(3, wave / 2)) == 0) {
                    enemyY[i] = Math.min(118, enemyY[i] + 1 + (wave >= 4 ? 1 : 0));
                    if ((animationTick + i) % 7 == 0) enemyX[i] = Math.max(14, Math.min(128, enemyX[i] + Integer.compare(73 + cameraStrafe, enemyX[i])));
                }
                if (enemyY[i] >= 108 && animationTick % 14 == 0) {
                    hp = Math.max(0, hp - (wave >= 4 ? 10 : 7)); hitFlash = 6; damageVignette = 8;
                    enemyY[i] = 92;
                    if (hp == 0) gameOver = true;
                }
            }
            if (kills >= wave * 5) { wave++; hp = Math.min(100, hp + 10); reserveAmmo += 12; }
            if (wave > 1 && kills >= 15) won = true;
        }
        if (app.equals("horror") && !gameOver && !won) {
            gameTicks++;
            if (gameTicks % 20 == 0 && flashlight) battery = Math.max(0, battery - 2);
            if (battery == 0) flashlight = false;
            if (gameTicks >= 60) {
                gameTicks = 0;
                if (horrorStep > 0 && !flashlight) fear = Math.min(100, fear + 5);
                else if (flashlight) fear = Math.max(0, fear - 2);
                // The creature occasionally surges forward. A lit flashlight repels it.
                if (horrorStep >= 2 && !flashlight && (animationTick % 3 == 0)) {
                    fear = Math.min(100, fear + 8);
                    scareFlash = 6;
                }
                if (fear >= 100) gameOver = true;
            }
        }
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        int actualMouseX = mouseX, actualMouseY = mouseY;
        // Soft dusk background stays in screen coordinates.
        g.fill(0, 0, width, height, 0xFF171C2B);
        for (int i = 0; i < 70; i++) {
            int x = Math.floorMod(i * 73 + 17, Math.max(1, width));
            int y = Math.floorMod(i * 41 + 9, Math.max(1, height));
            g.fill(x, y, x + (i % 5 == 0 ? 2 : 1), y + 1, i % 3 == 0 ? 0xFF766B9D : 0xFF414760);
        }
        g.pose().pushPose();
        g.pose().translate(width / 2.0f, height / 2.0f, 0);
        g.pose().scale(uiScale, uiScale, 1.0f);
        mouseX = (int) ((mouseX - width / 2.0f) / uiScale);
        mouseY = (int) ((mouseY - height / 2.0f) / uiScale);

        // A chunky, beveled pink phone frame.
        g.fill(left + 4, top + 5, left + 176, top + 228, 0xFF10131E);
        g.fill(left, top + 2, left + 174, top + 226, SHADOW);
        g.fill(left + 3, top, left + 171, top + 223, PINK);
        g.fill(left + 6, top + 3, left + 168, top + 220, LIGHT);
        g.fill(left + 9, top + 7, left + 165, top + 215, DARK);
        g.fill(left + 12, top + 10, left + 162, top + 212, 0xFF4C477A);

        // Bezel glints and screws.
        g.fill(left + 8, top + 9, left + 35, top + 11, WHITE);
        g.fill(left + 138, top + 9, left + 161, top + 11, 0xFFFFBFD8);
        g.fill(left + 7, top + 22, left + 10, top + 38, 0xFFFFBFD8);
        g.fill(left + 164, top + 45, left + 167, top + 70, SHADOW);
        g.fill(left + 74, top + 4, left + 101, top + 7, SHADOW);
        // Speaker and front camera.
        g.fill(left + 70, top + 13, left + 102, top + 16, 0xFF8D527C);
        g.fill(left + 111, top + 12, left + 117, top + 18, 0xFF624C79);
        g.fill(left + 113, top + 13, left + 115, top + 15, 0xFFB9D9E7);

        int sx = left + 14, sy = top + 23;
        g.fill(sx, sy, sx + 146, sy + 174, 0xFF25233E);

        if (app.equals("home")) {
            drawHome(g, sx, sy, mouseX, mouseY);
        } else if (app.equals("horror")) {
            drawHorror(g, sx, sy);
        } else if (app.equals("battle")) {
            drawBattle(g, sx, sy);
        } else {
            drawApp(g, sx, sy);
        }

        // Bottom bezel, tiny pink heart and navigation bar.
        g.fill(left + 70, top + 204, left + 104, top + 207, 0xFFB65D8A);
        g.fill(left + 84, top + 198, left + 88, top + 202, 0xFFFFD8E7);
        g.fill(left + 91, top + 198, left + 95, top + 202, 0xFFFFD8E7);
        g.fill(left + 87, top + 201, left + 93, top + 205, 0xFFFFD8E7);

        // Hardware side buttons, drawn outside the body.
        g.fill(left + 172, top + 47, left + 178, top + 71, SHADOW);
        g.fill(left + 172, top + 49, left + 176, top + 67, LIGHT);
        g.fill(left - 4, top + 61, left + 2, top + 82, SHADOW);
        g.fill(left - 3, top + 63, left + 1, top + 79, LIGHT);
        g.pose().popPose();
        super.render(g, actualMouseX, actualMouseY, partialTick);
    }

    private void drawHome(GuiGraphics g, int sx, int sy, int mouseX, int mouseY) {
        // Real PNG wallpaper asset bundled in the mod resources.
        g.blit(WALLPAPER, sx + 2, sy + 2, 0, 0, 142, 170, 584, 696);
        // Status row.
        g.fill(sx + 5, sy + 5, sx + 141, sy + 23, 0xFF45416F);
        g.drawString(font, "17:24", sx + 10, sy + 10, WHITE, false);
        g.drawString(font, "♥", sx + 112, sy + 9, 0xFFFFC4DF, false);
        g.drawString(font, "100%", sx + 119, sy + 9, WHITE, false);
        g.drawString(font, "Good evening!", sx + 9, sy + 27, WHITE, false);
        // Dock of app tiles over the wallpaper.
        drawAppIcon(g, sx + 5, sy + 132, 0xFFB8D89B, "✿");
        drawAppIcon(g, sx + 39, sy + 132, 0xFF9ED9EE, "♫");
        drawAppIcon(g, sx + 73, sy + 132, 0xFFEAC1E0, "♥");
        drawAppIcon(g, sx + 107, sy + 132, 0xFFC8B7F1, "⚙");
        g.drawString(font, "Garden", sx + 3, sy + 160, WHITE, false);
        g.drawString(font, "Music", sx + 40, sy + 160, WHITE, false);
        g.drawString(font, "Photos", sx + 71, sy + 160, WHITE, false);
        g.drawString(font, "Notes", sx + 108, sy + 160, WHITE, false);
        // Separate, clearly clickable game and settings shortcuts.
        g.fill(sx + 112, sy + 30, sx + 139, sy + 57, 0xFF211827);
        g.fill(sx + 114, sy + 32, sx + 137, sy + 55, 0xFF5A243E);
        g.fill(sx + 118, sy + 37, sx + 123, sy + 42, 0xFFFF4C70);
        g.fill(sx + 129, sy + 37, sx + 134, sy + 42, 0xFFFF4C70);
        g.drawString(font, "ZOMBIES", sx + 108, sy + 59, 0xFFFFD9E6, false);
        g.fill(sx + 118, sy + 70, sx + 139, sy + 91, 0xFFFFD5E6);
        g.drawCenteredString(font, Component.literal("⚙"), sx + 128, sy + 76, PURPLE);
        g.drawString(font, "SET", sx + 119, sy + 92, 0xFFFFD9E6, false);
    }

    private void drawBattle(GuiGraphics g, int sx, int sy) {
        // First-person, Call-of-Duty-inspired survival arena. Scene is drawn at native pixel resolution.
        final int vx = sx + 3, vy = sy + 24, vw = 140, vh = 101;
        g.fill(sx+2, sy+2, sx+144, sy+172, 0xFF090C12);
        g.fill(sx+2, sy+2, sx+144, sy+22, 0xFF171923);
        g.drawString(font, "LAST STAND", sx+7, sy+7, 0xFFFFB5D2, false);
        g.drawString(font, "WAVE " + wave, sx+99, sy+7, 0xFFFFD9E6, false);

        // Night-time ruined street: sky, distant skyline, fog and converging road lines.
        g.fill(vx, vy, vx+vw, vy+vh, 0xFF252B35);
        g.fill(vx, vy, vx+vw, vy+42, 0xFF202431);
        g.fill(vx, vy+42, vx+vw, vy+vh, 0xFF34363A);
        // Distant silhouettes
        for (int i=0;i<8;i++) {
            int bx=vx+i*19-3, bh=15+Math.floorMod(i*17+wave*3,20);
            g.fill(bx, vy+41-bh, bx+13, vy+43, 0xFF151A23);
            g.fill(bx+3, vy+44-bh, bx+5, vy+46-bh, 0xFF665A48);
            g.fill(bx+8, vy+34-bh, bx+10, vy+36-bh, 0xFF5B5044);
        }
        // Street walls create a strong first-person vanishing point.
        g.fill(vx, vy+38, vx+18, vy+vh, 0xFF171B22);
        g.fill(vx+122, vy+38, vx+vw, vy+vh, 0xFF191D25);
        for(int i=0;i<5;i++) {
            int yy=vy+45+i*12;
            g.fill(vx+2, yy, vx+15, yy+1, 0xFF343943);
            g.fill(vx+125, yy, vx+138, yy+1, 0xFF363A42);
        }
        // Perspective road markings and debris.
        for(int i=0;i<5;i++) {
            int yy=vy+48+i*13;
            int half=2+i*3;
            g.fill(vx+70-half, yy, vx+70+half, yy+1+i/2, 0xFF55504A);
        }
        g.fill(vx+22,vy+78,vx+31,vy+81,0xFF4A4542);
        g.fill(vx+105,vy+66,vx+112,vy+69,0xFF4A4542);
        g.fill(vx+48,vy+91,vx+56,vy+94,0xFF4A4542);

        // Zombies approach the player; distance controls their size and vertical position.
        for(int i=0;i<enemyAlive.length;i++) if(enemyAlive[i]) {
            int depth=Math.max(18, Math.min(118, enemyY[i]));
            int size=7+(depth-18)*36/100;
            int centerX=vx+enemyX[i]-cameraStrafe;
            centerX=Math.max(vx+size/2+1, Math.min(vx+vw-size/2-1, centerX));
            int footY=vy+43+(depth-18)*52/100;
            int bob=((animationTick/4+i)%2==0)?0:1;
            int bodyW=Math.max(4,size*3/5), bodyH=Math.max(4,size*3/4);
            int head=Math.max(3,size/3);
            // shadow, ragged legs, torso and swinging arms
            g.fill(centerX-bodyW/2-2,footY-1,centerX+bodyW/2+2,footY+2,0x88000000);
            g.fill(centerX-bodyW/2,footY-bodyH/3+bob,centerX-1,footY+1,0xFF292B2B);
            g.fill(centerX+1,footY-bodyH/3-bob,centerX+bodyW/2,footY+1,0xFF292B2B);
            g.fill(centerX-bodyW/2-2,footY-bodyH,centerX+bodyW/2+2,footY-bodyH/3,0xFF4A5A43);
            g.fill(centerX-bodyW/2-3,footY-bodyH+2+bob,centerX-bodyW/2,footY-bodyH/3,0xFF526148);
            g.fill(centerX+bodyW/2,footY-bodyH+1-bob,centerX+bodyW/2+3,footY-bodyH/3+2,0xFF526148);
            g.fill(centerX-head/2-1,footY-bodyH-head+1,centerX+head/2+1,footY-bodyH+2,0xFF69715A);
            g.fill(centerX-head/2,footY-bodyH-head+2,centerX+head/2,footY-bodyH,0xFF899071);
            if(size>17) {
                g.fill(centerX-head/2,footY-bodyH-head/2,centerX-head/2+2,footY-bodyH-head/2+2,0xFFFF4545);
                g.fill(centerX+head/2-2,footY-bodyH-head/2,centerX+head/2,footY-bodyH-head/2+2,0xFFFF4545);
                g.fill(centerX-bodyW/2,footY-bodyH/2,centerX+bodyW/2,footY-bodyH/2+2,0xFF743B3B);
            }
            if(enemyHp[i]>1) {
                g.fill(centerX-size/2,footY-bodyH-head-5,centerX+size/2,footY-bodyH-head-3,0xFF351D24);
                g.fill(centerX-size/2,footY-bodyH-head-5,centerX-size/2+size/2,footY-bodyH-head-3,0xFFFF536D);
            }
        }
        // Crosshair follows the tap/click point. Flash and hit marker are crisp overlays.
        int cx=vx+aimX, cy=vy+aimY;
        g.fill(cx-4,cy,cx-1,cy+1,0xFFE8F4E8); g.fill(cx+2,cy,cx+5,cy+1,0xFFE8F4E8);
        g.fill(cx,cy-4,cx+1,cy-1,0xFFE8F4E8); g.fill(cx,cy+2,cx+1,cy+5,0xFFE8F4E8);
        if(hitFlash>0) {
            g.fill(cx-5,cy-5,cx-2,cy-4,0xFFFF5B67); g.fill(cx+3,cy+4,cx+6,cy+5,0xFFFF5B67);
            g.fill(cx+3,cy-5,cx+6,cy-4,0xFFFF5B67); g.fill(cx-5,cy+4,cx-2,cy+5,0xFFFF5B67);
        }
        // First-person rifle and hands; recoil lifts the weapon, walking adds a subtle bob.
        int bob=(animationTick%8<4?0:1)+walkBob;
        int kick=weaponKick>0?weaponKick*2:0;
        int gx=vx+70, gy=vy+vh-3+bob+kick;
        g.fill(gx-24,gy-17,gx+24,gy+9,0xFF101219);
        g.fill(gx-18,gy-22,gx+18,gy+3,0xFF343944);
        g.fill(gx-13,gy-30,gx+13,gy-8,0xFF1A1E26);
        g.fill(gx-7,gy-38,gx+7,gy-16,0xFF525B65);
        g.fill(gx-4,gy-44,gx+4,gy-22,0xFF151920);
        g.fill(gx-2,gy-47,gx+2,gy-29,0xFF78818A);
        // Gloved hands gripping the weapon
        g.fill(gx-29,gy-11,gx-13,gy+3,0xFFB58A79);
        g.fill(gx+13,gy-11,gx+29,gy+3,0xFFB58A79);
        g.fill(gx-27,gy-9,gx-14,gy+1,0xFF614A48);
        g.fill(gx+14,gy-9,gx+27,gy+1,0xFF614A48);
        if(shotFlash>0) {
            g.fill(gx-7,gy-58,gx+7,gy-45,0xFFFFB73D);
            g.fill(gx-4,gy-65,gx+4,gy-49,0xFFFFF0B2);
            g.fill(gx-13,gy-56,gx-7,gy-48,0xFFFF7B35);
            g.fill(gx+7,gy-56,gx+13,gy-48,0xFFFF7B35);
        }
        if(reloadTicks>0) {
            int phase=reloadTicks%18;
            g.fill(gx-11,gy-15+phase/3,gx+11,gy-8+phase/3,0xFF75808A);
        }
        // HUD and damage feedback
        g.fill(sx+5,sy+128,sx+78,sy+132,0xFF542B3C);
        g.fill(sx+5,sy+128,sx+5+hp*73/100,sy+132,hp>30?0xFF77D7A1:0xFFFF536D);
        g.drawString(font,"♥ "+hp,sx+6,sy+135,hp>30?0xFFFFEAF3:0xFFFF6477,false);
        g.drawString(font,"KILLS "+kills,sx+46,sy+135,0xFFFFEAF3,false);
        g.drawString(font,ammo+" / "+reserveAmmo,sx+94,sy+135,0xFFFFD66B,false);
        drawHorrorButton(g,sx+5,sy+153,sx+34,sy+169,"◀");
        drawHorrorButton(g,sx+38,sy+153,sx+78,sy+169,"FIRE");
        drawHorrorButton(g,sx+82,sy+153,sx+111,sy+169,reloadTicks>0?"...":"RLD");
        drawHorrorButton(g,sx+115,sy+153,sx+141,sy+169,"EXIT");
        if(damageVignette>0) {
            g.fill(vx,vy,vx+vw,vy+3,0xBBFF253D); g.fill(vx,vy+vh-3,vx+vw,vy+vh,0xBBFF253D);
            g.fill(vx,vy,vx+3,vy+vh,0xBBFF253D); g.fill(vx+vw-3,vy,vx+vw,vy+vh,0xBBFF253D);
        }
        if(gameOver||won) {
            g.fill(sx+17,sy+57,sx+129,sy+103,0xF0000000);
            g.drawCenteredString(font,Component.literal(gameOver?"YOU DIED":"ROUND CLEARED"),sx+73,sy+64,gameOver?0xFFFF536D:0xFF8FFFC0);
            g.drawCenteredString(font,Component.literal("KILLS: "+kills),sx+73,sy+77,WHITE);
            g.drawCenteredString(font,Component.literal("TAP RETRY"),sx+73,sy+89,0xFFFFD9E6);
        }
    }

    private void drawHorror(GuiGraphics g, int sx, int sy) {
        // A tiny first-person survival-horror game rendered in the phone display.
        g.fill(sx + 2, sy + 2, sx + 144, sy + 172, 0xFF080912);
        g.fill(sx + 3, sy + 3, sx + 143, sy + 21, 0xFF211522);
        g.drawString(font, "NIGHT SHIFT", sx + 8, sy + 8, 0xFFFFB7C9, false);
        g.drawString(font, "FEAR " + fear + "%", sx + 91, sy + 8, 0xFFFF647E, false);
        g.fill(sx + 8, sy + 19, sx + 136, sy + 22, 0xFF4A263A);
        g.fill(sx + 8, sy + 19, sx + 8 + Math.min(128, fear * 128 / 100), sy + 22, 0xFFFF536D);
        // Use an actual pixel-art hallway PNG; perspective changes as player advances.
        int shake = scareFlash > 0 ? ((animationTick & 1) == 0 ? 2 : -2) : 0;
        // A subtle animated flicker makes the corridor feel alive without blurring pixel art.
        if ((animationTick / 8) % 5 == 0 && !flashlight) {
            g.fill(sx + 4, sy + 25, sx + 142, sy + 124, 0x33000000);
        }
        g.blit(HORROR_HALL, sx + 4 + shake, sy + 25, 0, 0, 138, 99, 640, 480);
        // Threat animates by bobbing and grows closer as the player advances.
        if (horrorStep > 0 || fear > 10) {
            int size = Math.min(66, 18 + horrorStep * 8 + fear / 12);
            int mx = sx + 75 - size / 2 + shake;
            int bob = (int) (Math.sin(animationTick * 0.18) * 3.0);
            int my = sy + 47 + Math.max(0, 27 - horrorStep * 3) + bob;
            if (flashlight) {
                g.fill(mx - 3, my - 3, mx + size + 3, my + size + 3, 0x55FFE6A0);
            }
            g.blit(HORROR_MONSTER, mx, my, 0, 0, size, size, 192, 256);
        }
        // Flashlight visibly lights the corridor; battery drains while held on.
        if (flashlight) {
            g.fill(sx + 7, sy + 29, sx + 139, sy + 31, 0xFFFFE5A5);
            g.fill(sx + 10, sy + 32, sx + 136, sy + 34, 0x99FFE5A5);
            g.fill(sx + 8, sy + 23, sx + 53, sy + 26, 0xFF443A2D);
            g.fill(sx + 8, sy + 23, sx + 8 + battery * 45 / 100, sy + 26, 0xFFFFD978);
        } else {
            g.fill(sx + 4, sy + 25, sx + 142, sy + 124, 0x18000000);
        }
        if (scareFlash > 0) g.fill(sx + 4, sy + 25, sx + 142, sy + 124, 0x44FF174F);
        g.fill(sx + 4, sy + 126, sx + 142, sy + 170, 0xFF17111F);
        String status = won ? "YOU ESCAPED!" : gameOver ? "YOU WERE CAUGHT" :
                horrorStep == 0 ? "Find the exit. Save your light." :
                flashlight ? "Light pushes it back!" : "It's getting closer...";
        g.drawCenteredString(font, Component.literal(status), sx + 73, sy + 129, won ? 0xFFB9F4C7 : 0xFFFFD7E4);
        g.drawCenteredString(font, Component.literal("DOOR " + steps + " / 5   BAT " + battery + "%"), sx + 73, sy + 137, 0xFFBDAFCB);
        // Big tactile controls, styled like pixel buttons.
        drawHorrorButton(g, sx + 8, sy + 145, sx + 43, sy + 164, "◀");
        drawHorrorButton(g, sx + 47, sy + 145, sx + 98, sy + 164, flashlight ? "LIGHT ON" : "LIGHT");
        drawHorrorButton(g, sx + 102, sy + 145, sx + 137, sy + 164, "▶");
        if (gameOver || won) {
            g.fill(sx + 20, sy + 65, sx + 126, sy + 97, 0xF0000000);
            g.drawCenteredString(font, Component.literal(won ? "YOU ESCAPED!" : "CAUGHT"), sx + 73, sy + 70, won ? 0xFFB9F4C7 : 0xFFFF536D);
            g.drawCenteredString(font, Component.literal("RIGHT: play again"), sx + 73, sy + 82, WHITE);
            g.drawCenteredString(font, Component.literal("LEFT: return home"), sx + 73, sy + 90, 0xFFFFD9E6);
        }
    }

    private void drawHorrorButton(GuiGraphics g, int x1, int y1, int x2, int y2, String label) {
        g.fill(x1 + 2, y1 + 2, x2 + 2, y2 + 2, 0xFF08070D);
        g.fill(x1, y1, x2, y2, 0xFF8C4266);
        g.fill(x1 + 2, y1 + 2, x2 - 2, y2 - 2, 0xFF382238);
        g.drawCenteredString(font, Component.literal(label), (x1 + x2) / 2, y1 + 6, 0xFFFFD9E6);
    }

    private void drawAppIcon(GuiGraphics g, int x, int y, int color, String symbol) {
        g.fill(x + 2, y + 3, x + 26, y + 27, 0xFF28223F);
        g.fill(x, y, x + 24, y + 24, 0xFFFFEAF3);
        g.fill(x + 2, y + 2, x + 22, y + 22, color);
        g.drawCenteredString(font, Component.literal(symbol), x + 12, y + 7, 0xFF4B3A67);
    }

    private void drawApp(GuiGraphics g, int sx, int sy) {
        g.fill(sx + 2, sy + 2, sx + 144, sy + 172, 0xFFFFEAF3);
        g.fill(sx + 2, sy + 2, sx + 144, sy + 25, PINK);
        g.drawString(font, "‹  Pink Phone", sx + 8, sy + 10, WHITE, false);
        switch (app) {
            case "garden" -> {
                g.drawCenteredString(font, Component.literal("Little Garden"), sx + 73, sy + 42, PURPLE);
                g.fill(sx + 25, sy + 78, sx + 121, sy + 128, 0xFFB5D59B);
                g.fill(sx + 39, sy + 65, sx + 55, sy + 96, 0xFF548A68);
                g.fill(sx + 33, sy + 59, sx + 61, sy + 77, 0xFF75AE78);
                g.fill(sx + 83, sy + 73, sx + 101, sy + 103, 0xFF548A68);
                g.fill(sx + 77, sy + 64, sx + 108, sy + 83, 0xFF75AE78);
                g.drawCenteredString(font, Component.literal("Water: " + gardenWater + "  /  10"), sx + 73, sy + 139, PURPLE);
                g.fill(sx+35, sy+148, sx+111, sy+164, 0xFF8FCB91);
                g.drawCenteredString(font, Component.literal("WATER PLANT"), sx+73, sy+153, 0xFF244C39);
            }
            case "music" -> {
                g.drawCenteredString(font, Component.literal(musicPlaying ? "NOW PLAYING" : "MUSIC PLAYER"), sx + 73, sy + 42, PURPLE);
                g.fill(sx + 35, sy + 62, sx + 111, sy + 138, 0xFFD8C5EF);
                g.fill(sx + 51, sy + 79, sx + 95, sy + 121, 0xFFB58BCB);
                g.drawCenteredString(font, Component.literal("♫"), sx + 73, sy + 91, WHITE);
                g.drawCenteredString(font, Component.literal("Minecraft Disc"), sx + 73, sy + 145, PURPLE);
                g.drawCenteredString(font, Component.literal(MUSIC_DISC_NAMES[musicTrack]), sx + 73, sy + 135, PURPLE);
                g.fill(sx+12, sy+151, sx+61, sy+166, 0xFFFFD5E6);
                g.fill(sx+85, sy+151, sx+134, sy+166, 0xFFFFD5E6);
                g.drawCenteredString(font, Component.literal(musicPlaying ? "PAUSE" : "PLAY"), sx+36, sy+155, PURPLE);
                g.drawCenteredString(font, Component.literal("NEXT ▶"), sx+109, sy+155, PURPLE);
            }
            case "photos" -> {
                g.drawCenteredString(font, Component.literal("Camera / Gallery"), sx + 73, sy + 39, PURPLE);
                int[] colors = {0xFFFFC5D9,0xFFB8D9E7,0xFFB9D79E,0xFFD5B8EB,0xFFFFDFA7,0xFFECA6C8};
                for (int i = 0; i < 6; i++) {
                    int x = sx + 13 + (i % 3) * 41, y = sy + 54 + (i / 3) * 36;
                    g.fill(x, y, x + 34, y + 30, 0xFFFFFFFF);
                    g.fill(x + 3, y + 3, x + 31, y + 27, colors[i]);
                    g.fill(x + 9, y + 11, x + 25, y + 14, 0xFFFFEDF5);
                    if (i == photoIndex) { g.fill(x, y, x+34, y+2, PURPLE); g.fill(x, y+28, x+34, y+30, PURPLE); }
                }
                g.fill(sx+20, sy+132, sx+126, sy+151, 0xFF9ED9EE);
                g.drawCenteredString(font, Component.literal("TAKE PHOTO  [F2]"), sx+73, sy+138, 0xFF253E5A);
                g.drawCenteredString(font, Component.literal("Saved screenshots: " + photosTaken), sx+73, sy+153, PURPLE);
            }
            case "notes" -> {
                g.drawCenteredString(font, Component.literal(notesEditing ? "Notes · EDITING" : "Sweet Notes"), sx + 73, sy + 42, PURPLE);
                g.fill(sx+11, sy+60, sx+135, sy+122, 0xFFFFFFFF);
                String shown = noteText.length() > 25 ? noteText.substring(0,25) : noteText;
                g.drawWordWrap(font, Component.literal(shown), sx+16, sy+68, 112, PURPLE);
                g.drawCenteredString(font, Component.literal(notesEditing ? "Type · Enter saves" : "Click note to edit"), sx+73, sy+132, PURPLE);
                g.drawCenteredString(font, Component.literal("Backspace deletes"), sx+73, sy+145, PURPLE);
            }
            case "settings" -> {
                g.drawCenteredString(font, Component.literal("Settings"), sx + 73, sy + 42, PURPLE);
                String[] rows = {"Wallpaper: " + new String[]{"sunset","rose","mint"}[wallpaperIndex],"Sound: " + (soundEnabled ? "ON" : "OFF"),"Notifications: " + (notifications ? "ON" : "OFF"),"Reset app data"};
                for (int i=0;i<rows.length;i++) {
                    int y=sy+63+i*25;
                    g.fill(sx+10,y,sx+136,y+19,0xFFFFD5E6);
                    g.drawString(font,rows[i],sx+15,y+6,PURPLE,false);
                }
            }
            default -> g.drawCenteredString(font, Component.literal("Coming soon ♡"), sx + 73, sy + 90, PURPLE);
        }
        g.fill(sx + 48, sy + 157, sx + 98, sy + 161, 0xFFB85F8B);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button != 0) return super.mouseClicked(mouseX, mouseY, button);
        mouseX = (mouseX - width / 2.0) / uiScale;
        mouseY = (mouseY - height / 2.0) / uiScale;
        int sx = left + 14, sy = top + 23;
        if (app.equals("battle")) {
            if (gameOver || won) {
                if(mouseY >= sy+153 && mouseX >= sx+115) { app="home"; return true; }
                resetBattle(); return true;
            }
            if(mouseY >= sy+153 && mouseY <= sy+171) {
                if(mouseX>=sx+5 && mouseX<sx+35) { cameraStrafe=Math.max(-28,cameraStrafe-8); walkBob=(walkBob+1)%3; }
                else if(mouseX>=sx+38 && mouseX<sx+79) { aimX=70; aimY=54; fireBattleShot(); }
                else if(mouseX>=sx+82 && mouseX<sx+112) { if(ammo<12 && reserveAmmo>0 && reloadTicks==0) reloadTicks=18; }
                else if(mouseX>=sx+115) { app="home"; return true; }
                return true;
            }
            if(mouseY>=sy+24 && mouseY<=sy+125 && mouseX>=sx+3 && mouseX<=sx+143) {
                aimX=(int)mouseX-(sx+3); aimY=(int)mouseY-(sy+24); fireBattleShot(); return true;
            }
            return true;
        }
        if (app.equals("horror")) {
            if (mouseY >= sy + 145 && mouseY <= sy + 166) {
                if (mouseX >= sx + 8 && mouseX <= sx + 43) {
                    horrorStep = Math.max(0, horrorStep - 1);
                    steps = Math.max(0, steps - 1);
                    fear = Math.max(0, fear - 12);
                    if (won || gameOver) { app = "home"; return true; }
                    gameTicks = 0;
                } else if (mouseX >= sx + 47 && mouseX <= sx + 98) {
                    if (battery > 0) flashlight = !flashlight;
                    fear = Math.max(0, fear - (flashlight ? 8 : 3));
                    gameTicks = 0;
                } else if (mouseX >= sx + 102 && mouseX <= sx + 137) {
                    if (gameOver || won) {
                        horrorStep = 0; steps = 0; fear = 0; flashlight = false; gameTicks = 0; gameOver = false; won = false; battery = 100;
                    } else {
                        horrorStep++;
                        steps++;
                        fear = Math.min(100, fear + (flashlight ? 3 : 13));
                        if (horrorStep >= 5 && fear < 100) won = true;
                        if (fear >= 100) gameOver = true;
                        gameTicks = 0;
                    }
                }
                return true;
            }
            if (mouseY >= sy && mouseY <= sy + 23 && mouseX >= sx && mouseX <= sx + 70) { app = "home"; return true; }
            return true;
        }
        if (app.equals("garden")) {
            if (mouseY >= sy+145 && mouseY <= sy+168) gardenWater = Math.min(10, gardenWater+1);
            return true;
        }
        if (app.equals("music")) {
            if (mouseY >= sy+150 && mouseY <= sy+169) {
                if (mouseX < sx+72) {
                    if (musicPlaying) {
                        Minecraft.getInstance().getSoundManager().stop();
                        musicPlaying = false;
                    } else {
                        Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forMusic(MUSIC_DISC_SOUNDS[musicTrack]));
                        musicPlaying = true;
                    }
                } else {
                    if (musicPlaying) Minecraft.getInstance().getSoundManager().stop();
                    musicTrack = (musicTrack + 1) % MUSIC_DISC_SOUNDS.length;
                    if (musicPlaying) Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forMusic(MUSIC_DISC_SOUNDS[musicTrack]));
                }
            }
            return true;
        }
        if (app.equals("photos")) {
            if (mouseY >= sy+132 && mouseY <= sy+153) {
                // Queue Minecraft's native screenshot key so the actual game frame is saved to screenshots/.
                KeyMapping.click(Minecraft.getInstance().options.keyScreenshot.getKey());
                photosTaken++;
            } else if (mouseY >= sy+54 && mouseY <= sy+126) {
                int col = Math.max(0, Math.min(2, ((int)mouseX-(sx+13))/41));
                int row = mouseY >= sy+90 ? 1 : 0;
                photoIndex = row*3+col;
            }
            return true;
        }
        if (app.equals("notes")) {
            if (mouseY >= sy+58 && mouseY <= sy+125) notesEditing = true;
            else if (mouseY >= sy+130 && mouseY <= sy+153) notesEditing = !notesEditing;
            return true;
        }
        if (app.equals("settings")) {
            int row = ((int)mouseY - (sy+63))/25;
            if (mouseY >= sy+60 && row == 0) wallpaperIndex = (wallpaperIndex+1)%3;
            else if (row == 1) soundEnabled = !soundEnabled;
            else if (row == 2) notifications = !notifications;
            else if (row == 3) { gardenWater=0; Minecraft.getInstance().getSoundManager().stop(); musicPlaying=false; musicTrack=0; photoIndex=0; photosTaken=0; noteText="Remember the stars"; }
            return true;
        }
        if (app.equals("home") && mouseX >= sx + 110 && mouseX <= sx + 142 && mouseY >= sy + 27 && mouseY <= sy + 64) {
            app = "battle"; resetBattle(); return true;
        }
        if (app.equals("home") && mouseX >= sx + 115 && mouseX <= sx + 142 && mouseY >= sy + 68 && mouseY <= sy + 101) {
            app = "settings"; return true;
        }
        if (app.equals("home") && mouseY >= sy + 128 && mouseY <= sy + 172) {
            if (mouseX >= sx + 4 && mouseX < sx + 38) app = "garden";
            else if (mouseX >= sx + 38 && mouseX < sx + 72) app = "music";
            else if (mouseX >= sx + 72 && mouseX < sx + 106) app = "photos";
            else if (mouseX >= sx + 106 && mouseX < sx + 144) app = "notes";
            else return super.mouseClicked(mouseX, mouseY, button);
            return true;
        }
        if (!app.equals("home") && mouseX >= sx && mouseX <= sx + 45 && mouseY >= sy && mouseY <= sy + 25) {
            app = "home";
            return true;
        }
        if (mouseX < left || mouseX > left + 180 || mouseY < top || mouseY > top + 230) {
            onClose();
            return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean charTyped(char codePoint, int modifiers) {
        if (app.equals("notes") && notesEditing && !Character.isISOControl(codePoint) && noteText.length() < 90) {
            noteText += codePoint;
            return true;
        }
        return super.charTyped(codePoint, modifiers);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (app.equals("battle")) {
            if (gameOver || won) { if(keyCode==32 || keyCode==82 || keyCode==257) resetBattle(); else if(keyCode==27) app="home"; return true; }
            if (keyCode==65 || keyCode==263) { cameraStrafe=Math.max(-28,cameraStrafe-5); walkBob=(walkBob+1)%3; return true; }
            if (keyCode==68 || keyCode==262) { cameraStrafe=Math.min(28,cameraStrafe+5); walkBob=(walkBob+1)%3; return true; }
            if (keyCode==87 || keyCode==265) { for(int i=0;i<enemyAlive.length;i++) if(enemyAlive[i]) enemyY[i]=Math.min(118,enemyY[i]+4); walkBob=(walkBob+1)%3; return true; }
            if (keyCode==83 || keyCode==264) { for(int i=0;i<enemyAlive.length;i++) if(enemyAlive[i]) enemyY[i]=Math.max(30,enemyY[i]-4); walkBob=(walkBob+1)%3; return true; }
            if (keyCode==32 || keyCode==77) { aimX=70; aimY=54; fireBattleShot(); return true; }
            if (keyCode==82) { if(ammo<12 && reserveAmmo>0 && reloadTicks==0) reloadTicks=18; return true; }
            if (keyCode==27) { app="home"; return true; }
        }
        if (app.equals("horror")) {
            // A/Left retreats, D/Right advances, Space toggles the flashlight.
            if (keyCode == 263 || keyCode == 65) {
                horrorStep = Math.max(0, horrorStep - 1);
                steps = Math.max(0, steps - 1);
                fear = Math.max(0, fear - 12);
                if (won || gameOver) { app = "home"; return true; }
                gameTicks = 0;
                return true;
            }
            if (keyCode == 262 || keyCode == 68) {
                if (gameOver || won) {
                    horrorStep = 0; steps = 0; fear = 0; flashlight = false; gameOver = false; won = false; battery = 100;
                } else {
                    horrorStep++; steps++;
                    fear = Math.min(100, fear + (flashlight ? 3 : 13));
                    if (horrorStep >= 5 && fear < 100) won = true;
                    if (fear >= 100) gameOver = true;
                }
                gameTicks = 0;
                return true;
            }
            if (keyCode == 32) {
                if (battery > 0) flashlight = !flashlight;
                fear = Math.max(0, fear - (flashlight ? 8 : 3));
                gameTicks = 0;
                return true;
            }
        }
        if (app.equals("notes") && notesEditing) {
            if (keyCode == 256 || keyCode == 257) { notesEditing = false; return true; }
            if (keyCode == 259 && !noteText.isEmpty()) { noteText = noteText.substring(0, noteText.length()-1); return true; }
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    private void fireBattleShot() {
        if(gameOver || won) { resetBattle(); return; }
        if(reloadTicks>0) return;
        if(ammo<=0) { if(reserveAmmo>0) reloadTicks=18; return; }
        ammo--; shotFlash=4; weaponKick=4;
        int target=-1, best=9999;
        // The tap/crosshair hits the zombie occupying that point in first-person perspective.
        for(int i=0;i<enemyAlive.length;i++) if(enemyAlive[i]) {
            int depth=Math.max(18,Math.min(118,enemyY[i]));
            int size=7+(depth-18)*36/100;
            int centerX=Math.max(size/2+1,Math.min(139-size/2,enemyX[i]-cameraStrafe));
            int footY=43+(depth-18)*52/100;
            int centerY=footY-(size*3/4)/2-size/6;
            int dx=Math.abs(centerX-aimX), dy=Math.abs(centerY-aimY);
            int score=dx+dy;
            int hitRadius=Math.max(4,size/2+2);
            if(dx<=hitRadius && dy<=hitRadius && score<best) { best=score; target=i; }
        }
        if(target>=0) {
            hitFlash=5; enemyHp[target]--;
            if(enemyHp[target]<=0) { enemyAlive[target]=false; kills++; if(kills>=15) won=true; }
        }
    }

    private void resetBattle() {
        app="battle"; hp=100; ammo=12; reserveAmmo=60; kills=0; wave=1; shotFlash=0; hitFlash=0; reloadTicks=0; spawnTicks=0; gameOver=false; won=false; playerX=73; playerY=139; cameraStrafe=0; weaponKick=0; walkBob=0; damageVignette=0; aimX=70; aimY=54;
        for(int i=0;i<enemyAlive.length;i++) { enemyAlive[i]=false; enemyHp[i]=1; enemyAttack[i]=0; }
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
