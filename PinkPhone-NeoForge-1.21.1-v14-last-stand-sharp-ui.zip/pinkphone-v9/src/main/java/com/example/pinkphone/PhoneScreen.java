package com.example.pinkphone;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;

public class PhoneScreen extends Screen {
    private String app = "home";
    private int page = 0;
    private int horrorStep = 0;
    private int fear = 0;
    private boolean flashlight = false;
    private static final ResourceLocation WALLPAPER = ResourceLocation.fromNamespaceAndPath("pinkphone", "textures/gui/wallpaper_sunset.png");
    private static final ResourceLocation HORROR_HALL = ResourceLocation.fromNamespaceAndPath("pinkphone", "textures/gui/horror_hall.png");
    private static final ResourceLocation HORROR_MONSTER = ResourceLocation.fromNamespaceAndPath("pinkphone", "textures/gui/horror_monster.png");

    private int left, top;
    private float uiScale = 1.0f;
    private int gameTicks = 0;
    private int steps = 0;
    private boolean gameOver = false;
    private boolean won = false;
    // LAST STAND: compact top-down arena shooter, fully drawn with crisp GUI primitives.
    private int playerX = 73, playerY = 139;
    private int hp = 100, ammo = 12, reserveAmmo = 48, kills = 0, wave = 1;
    private int shotFlash = 0, hitFlash = 0, reloadTicks = 0, spawnTicks = 0;
    private int[] enemyX = new int[8], enemyY = new int[8], enemyHp = new int[8];
    private boolean[] enemyAlive = new boolean[8];
    private int aimX = 73, aimY = 80;
    private int battery = 100;
    private int animationTick = 0;
    private int scareFlash = 0;
    private static final int PINK = 0xFFF18BB9;
    private static final int LIGHT = 0xFFFFD5E6;
    private static final int PALE = 0xFFFFEEF5;
    private static final int DARK = 0xFF302943;
    private static final int PURPLE = 0xFF66558D;
    private static final int SHADOW = 0xFFB85F8B;
    private static final int WHITE = 0xFFFFF9FC;

    public PhoneScreen() {
        super(Component.literal("Pink Phone"));
    }

    @Override
    protected void init() {
        // Use INTEGER scaling only. Fractional pose scales (for example 1.37x)
        // make pixel art and small font edges look soft in Minecraft.
        // The phone's logical canvas is 178x230; 2x is used only when it fits.
        boolean canUse2x = this.width >= 178 * 2 + 16 && this.height >= 230 * 2 + 16;
        uiScale = canUse2x ? 2.0f : 1.0f;
        left = -87;
        top = -112;
    }

    @Override
    public void tick() {
        super.tick();
        animationTick++;
        if (scareFlash > 0) scareFlash--;
        if (app.equals("battle") && !gameOver && !won) {
            if (shotFlash > 0) shotFlash--;
            if (hitFlash > 0) hitFlash--;
            if (reloadTicks > 0 && --reloadTicks == 0) {
                int need = 12 - ammo;
                int take = Math.min(need, reserveAmmo);
                ammo += take; reserveAmmo -= take;
            }
            spawnTicks++;
            if (spawnTicks >= Math.max(18, 54 - wave * 4)) {
                spawnTicks = 0;
                for (int i=0;i<enemyAlive.length;i++) if (!enemyAlive[i]) {
                    enemyAlive[i] = true; enemyHp[i] = wave >= 4 ? 2 : 1;
                    int side = (animationTick / 7 + i * 3) % 4;
                    enemyX[i] = side == 0 ? 15 : side == 1 ? 131 : 20 + (i * 17) % 106;
                    enemyY[i] = side == 2 ? 48 : side == 3 ? 142 : 52 + (i * 11) % 75;
                    break;
                }
            }
            for (int i=0;i<enemyAlive.length;i++) if (enemyAlive[i]) {
                int dx = Integer.compare(playerX, enemyX[i]), dy = Integer.compare(playerY, enemyY[i]);
                if ((animationTick + i) % 3 == 0) { enemyX[i] += dx; enemyY[i] += dy; }
                if (Math.abs(playerX-enemyX[i]) < 5 && Math.abs(playerY-enemyY[i]) < 5 && animationTick % 12 == 0) {
                    hp = Math.max(0, hp - 7); hitFlash = 5; if (hp == 0) gameOver = true;
                }
            }
            if (kills >= wave * 5) { wave++; hp = Math.min(100, hp + 10); reserveAmmo += 12; }
        }
        if (app.equals("horror") && !gameOver && !won) {
            gameTicks++;
            if (gameTicks % 20 == 0 && flashlight) battery = Math.max(0, battery - 2);
            if (battery == 0) flashlight = false;
            if (gameTicks >= 60) {
                gameTicks = 0;
                if (horrorStep > 0 && !flashlight) fear = Math.min(100, fear + 5);
                else if (flashlight) fear = Math.max(0, fear - 2);
                // The creature occasionally surges forward. A lit flashlight repels it.
                if (horrorStep >= 2 && !flashlight && (animationTick % 3 == 0)) {
                    fear = Math.min(100, fear + 8);
                    scareFlash = 6;
                }
                if (fear >= 100) gameOver = true;
            }
        }
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        int actualMouseX = mouseX, actualMouseY = mouseY;
        // Soft dusk background stays in screen coordinates.
        g.fill(0, 0, width, height, 0xFF171C2B);
        for (int i = 0; i < 70; i++) {
            int x = Math.floorMod(i * 73 + 17, Math.max(1, width));
            int y = Math.floorMod(i * 41 + 9, Math.max(1, height));
            g.fill(x, y, x + (i % 5 == 0 ? 2 : 1), y + 1, i % 3 == 0 ? 0xFF766B9D : 0xFF414760);
        }
        g.pose().pushPose();
        g.pose().translate(width / 2.0f, height / 2.0f, 0);
        g.pose().scale(uiScale, uiScale, 1.0f);
        mouseX = (int) ((mouseX - width / 2.0f) / uiScale);
        mouseY = (int) ((mouseY - height / 2.0f) / uiScale);

        // A chunky, beveled pink phone frame.
        g.fill(left + 4, top + 5, left + 176, top + 228, 0xFF10131E);
        g.fill(left, top + 2, left + 174, top + 226, SHADOW);
        g.fill(left + 3, top, left + 171, top + 223, PINK);
        g.fill(left + 6, top + 3, left + 168, top + 220, LIGHT);
        g.fill(left + 9, top + 7, left + 165, top + 215, DARK);
        g.fill(left + 12, top + 10, left + 162, top + 212, 0xFF4C477A);

        // Bezel glints and screws.
        g.fill(left + 8, top + 9, left + 35, top + 11, WHITE);
        g.fill(left + 138, top + 9, left + 161, top + 11, 0xFFFFBFD8);
        g.fill(left + 7, top + 22, left + 10, top + 38, 0xFFFFBFD8);
        g.fill(left + 164, top + 45, left + 167, top + 70, SHADOW);
        g.fill(left + 74, top + 4, left + 101, top + 7, SHADOW);
        // Speaker and front camera.
        g.fill(left + 70, top + 13, left + 102, top + 16, 0xFF8D527C);
        g.fill(left + 111, top + 12, left + 117, top + 18, 0xFF624C79);
        g.fill(left + 113, top + 13, left + 115, top + 15, 0xFFB9D9E7);

        int sx = left + 14, sy = top + 23;
        g.fill(sx, sy, sx + 146, sy + 174, 0xFF25233E);

        if (app.equals("home")) {
            drawHome(g, sx, sy, mouseX, mouseY);
        } else if (app.equals("horror")) {
            drawHorror(g, sx, sy);
        } else if (app.equals("battle")) {
            drawBattle(g, sx, sy);
        } else {
            drawApp(g, sx, sy);
        }

        // Bottom bezel, tiny pink heart and navigation bar.
        g.fill(left + 70, top + 204, left + 104, top + 207, 0xFFB65D8A);
        g.fill(left + 84, top + 198, left + 88, top + 202, 0xFFFFD8E7);
        g.fill(left + 91, top + 198, left + 95, top + 202, 0xFFFFD8E7);
        g.fill(left + 87, top + 201, left + 93, top + 205, 0xFFFFD8E7);

        // Hardware side buttons, drawn outside the body.
        g.fill(left + 172, top + 47, left + 178, top + 71, SHADOW);
        g.fill(left + 172, top + 49, left + 176, top + 67, LIGHT);
        g.fill(left - 4, top + 61, left + 2, top + 82, SHADOW);
        g.fill(left - 3, top + 63, left + 1, top + 79, LIGHT);
        g.pose().popPose();
        super.render(g, actualMouseX, actualMouseY, partialTick);
    }

    private void drawHome(GuiGraphics g, int sx, int sy, int mouseX, int mouseY) {
        // Real PNG wallpaper asset bundled in the mod resources.
        g.blit(WALLPAPER, sx + 2, sy + 2, 0, 0, 142, 170, 584, 696);
        // Status row.
        g.fill(sx + 5, sy + 5, sx + 141, sy + 23, 0xFF45416F);
        g.drawString(font, "17:24", sx + 10, sy + 10, WHITE, false);
        g.drawString(font, "♥", sx + 112, sy + 9, 0xFFFFC4DF, false);
        g.drawString(font, "100%", sx + 119, sy + 9, WHITE, false);
        g.drawString(font, "Good evening!", sx + 9, sy + 27, WHITE, false);
        // Dock of app tiles over the wallpaper.
        drawAppIcon(g, sx + 5, sy + 132, 0xFFB8D89B, "✿");
        drawAppIcon(g, sx + 39, sy + 132, 0xFF9ED9EE, "♫");
        drawAppIcon(g, sx + 73, sy + 132, 0xFFEAC1E0, "♥");
        drawAppIcon(g, sx + 107, sy + 132, 0xFFC8B7F1, "⚙");
        g.drawString(font, "Garden", sx + 3, sy + 160, WHITE, false);
        g.drawString(font, "Music", sx + 40, sy + 160, WHITE, false);
        g.drawString(font, "Photos", sx + 71, sy + 160, WHITE, false);
        g.drawString(font, "Notes", sx + 108, sy + 160, WHITE, false);
        // Separate, clearly clickable game and settings shortcuts.
        g.fill(sx + 112, sy + 30, sx + 139, sy + 57, 0xFF211827);
        g.fill(sx + 114, sy + 32, sx + 137, sy + 55, 0xFF5A243E);
        g.fill(sx + 118, sy + 37, sx + 123, sy + 42, 0xFFFF4C70);
        g.fill(sx + 129, sy + 37, sx + 134, sy + 42, 0xFFFF4C70);
        g.drawString(font, "BATTLE", sx + 110, sy + 59, 0xFFFFD9E6, false);
        g.fill(sx + 118, sy + 70, sx + 139, sy + 91, 0xFFFFD5E6);
        g.drawCenteredString(font, Component.literal("⚙"), sx + 128, sy + 76, PURPLE);
        g.drawString(font, "SET", sx + 119, sy + 92, 0xFFFFD9E6, false);
    }

    private void drawBattle(GuiGraphics g, int sx, int sy) {
        // Pixel-sharp top-down arena. All art is drawn directly at GUI resolution,
        // avoiding scaled PNG screenshots and texture filtering.
        g.fill(sx+2,sy+2,sx+144,sy+172,0xFF10131C);
        g.fill(sx+2,sy+2,sx+144,sy+22,0xFF272038);
        g.drawString(font,"LAST STAND",sx+7,sy+7,0xFFFFB5D2,false);
        g.drawString(font,"WAVE "+wave,sx+94,sy+7,0xFFFFD9E6,false);
        int ax=sx+5, ay=sy+25, aw=136, ah=117;
        g.fill(ax,ay,ax+aw,ay+ah,0xFF202A32);
        // Floor tiles and tactical cover.
        for(int yy=0;yy<6;yy++) for(int xx=0;xx<7;xx++) {
            int c=((xx+yy)&1)==0?0xFF26323A:0xFF222D35;
            g.fill(ax+xx*19,ay+yy*19,Math.min(ax+aw,ax+(xx+1)*19),Math.min(ay+ah,ay+(yy+1)*19),c);
        }
        g.fill(ax+18,ay+28,ax+38,ay+39,0xFF56616A); g.fill(ax+19,ay+29,ax+37,ay+37,0xFF7C8589);
        g.fill(ax+91,ay+65,ax+119,ay+77,0xFF56616A); g.fill(ax+93,ay+67,ax+117,ay+75,0xFF7C8589);
        g.fill(ax+52,ay+83,ax+65,ay+94,0xFF56616A); g.fill(ax+54,ay+85,ax+63,ay+92,0xFF7C8589);
        for(int i=0;i<enemyAlive.length;i++) if(enemyAlive[i]) {
            int ex=ax+enemyX[i], ey=ay+(enemyY[i]-30);
            // Animated enemy drone/soldier sprite built from crisp rectangles.
            int bob=(animationTick+i*3)%8<4?0:1;
            g.fill(ex-4,ey-4+bob,ex+5,ey+5+bob,0xFF080B10);
            g.fill(ex-3,ey-3+bob,ex+4,ey+4+bob,0xFFB93857);
            g.fill(ex-2,ey-1+bob,ex+3,ey+1+bob,0xFFFF6578);
            g.fill(ex-2,ey-3+bob,ex-1,ey-2+bob,0xFFFFF0B8);
            g.fill(ex+2,ey-3+bob,ex+3,ey-2+bob,0xFFFFF0B8);
            if(enemyHp[i]>1) g.fill(ex-4,ey-7,ex+5,ey-6,0xFFFF6578);
        }
        // Player sprite and animated muzzle flash.
        int px=ax+playerX, py=ay+(playerY-30);
        g.fill(px-5,py-5,px+6,py+6,0xFF080B10);
        g.fill(px-4,py-4,px+5,py+5,0xFF6CC7E8);
        g.fill(px-2,py-2,px+3,py+3,0xFFD9F7FF);
        g.fill(px-1,py-7,px+2,py-4,0xFFB9EFFF);
        if(shotFlash>0) {
            g.fill(px+3,py-2,px+12,py+3,0xFFFFD66B);
            g.fill(px+7,py-1,px+15,py+2,0xFFFFF4C2);
        }
        // Crosshair, health, ammunition and hit feedback.
        g.fill(ax+aimX-4,ay+aimY-30,ax+aimX+5,ay+aimY-29,0xFFFFD6E5);
        g.fill(ax+aimX,ay+aimY-34,ax+aimX+1,ay+aimY-25,0xFFFFD6E5);
        g.fill(sx+6,sy+145,sx+80,sy+149,0xFF542B3C);
        g.fill(sx+6,sy+145,sx+6+hp*74/100,sy+149, hp>30?0xFF77D7A1:0xFFFF536D);
        g.drawString(font,"HP "+hp,sx+7,sy+134,0xFFFFEAF3,false);
        g.drawString(font,"K.O. "+kills,sx+51,sy+134,0xFFFFEAF3,false);
        g.drawString(font,ammo+" / "+reserveAmmo,sx+99,sy+134,0xFFFFD66B,false);
        drawHorrorButton(g,sx+5,sy+153,sx+34,sy+169,"MOVE");
        drawHorrorButton(g,sx+38,sy+153,sx+78,sy+169,"FIRE");
        drawHorrorButton(g,sx+82,sy+153,sx+111,sy+169,"RLD");
        drawHorrorButton(g,sx+115,sy+153,sx+141,sy+169,"EXIT");
        if(hitFlash>0) g.fill(sx+3,sy+24,sx+143,sy+142,0x33FF203F);
        if(gameOver||won) {
            g.fill(sx+17,sy+61,sx+129,sy+102,0xF0000000);
            g.drawCenteredString(font,Component.literal(gameOver?"YOU WERE DOWNED":"ARENA CLEARED"),sx+73,sy+68,gameOver?0xFFFF536D:0xFF8FFFC0);
            g.drawCenteredString(font,Component.literal("KILLS: "+kills),sx+73,sy+80,WHITE);
            g.drawCenteredString(font,Component.literal("RIGHT: RETRY"),sx+73,sy+90,0xFFFFD9E6);
        }
    }

    private void drawHorror(GuiGraphics g, int sx, int sy) {
        // A tiny first-person survival-horror game rendered in the phone display.
        g.fill(sx + 2, sy + 2, sx + 144, sy + 172, 0xFF080912);
        g.fill(sx + 3, sy + 3, sx + 143, sy + 21, 0xFF211522);
        g.drawString(font, "NIGHT SHIFT", sx + 8, sy + 8, 0xFFFFB7C9, false);
        g.drawString(font, "FEAR " + fear + "%", sx + 91, sy + 8, 0xFFFF647E, false);
        g.fill(sx + 8, sy + 19, sx + 136, sy + 22, 0xFF4A263A);
        g.fill(sx + 8, sy + 19, sx + 8 + Math.min(128, fear * 128 / 100), sy + 22, 0xFFFF536D);
        // Use an actual pixel-art hallway PNG; perspective changes as player advances.
        int shake = scareFlash > 0 ? ((animationTick & 1) == 0 ? 2 : -2) : 0;
        // A subtle animated flicker makes the corridor feel alive without blurring pixel art.
        if ((animationTick / 8) % 5 == 0 && !flashlight) {
            g.fill(sx + 4, sy + 25, sx + 142, sy + 124, 0x33000000);
        }
        g.blit(HORROR_HALL, sx + 4 + shake, sy + 25, 0, 0, 138, 99, 640, 480);
        // Threat animates by bobbing and grows closer as the player advances.
        if (horrorStep > 0 || fear > 10) {
            int size = Math.min(66, 18 + horrorStep * 8 + fear / 12);
            int mx = sx + 75 - size / 2 + shake;
            int bob = (int) (Math.sin(animationTick * 0.18) * 3.0);
            int my = sy + 47 + Math.max(0, 27 - horrorStep * 3) + bob;
            if (flashlight) {
                g.fill(mx - 3, my - 3, mx + size + 3, my + size + 3, 0x55FFE6A0);
            }
            g.blit(HORROR_MONSTER, mx, my, 0, 0, size, size, 192, 256);
        }
        // Flashlight visibly lights the corridor; battery drains while held on.
        if (flashlight) {
            g.fill(sx + 7, sy + 29, sx + 139, sy + 31, 0xFFFFE5A5);
            g.fill(sx + 10, sy + 32, sx + 136, sy + 34, 0x99FFE5A5);
            g.fill(sx + 8, sy + 23, sx + 53, sy + 26, 0xFF443A2D);
            g.fill(sx + 8, sy + 23, sx + 8 + battery * 45 / 100, sy + 26, 0xFFFFD978);
        } else {
            g.fill(sx + 4, sy + 25, sx + 142, sy + 124, 0x18000000);
        }
        if (scareFlash > 0) g.fill(sx + 4, sy + 25, sx + 142, sy + 124, 0x44FF174F);
        g.fill(sx + 4, sy + 126, sx + 142, sy + 170, 0xFF17111F);
        String status = won ? "YOU ESCAPED!" : gameOver ? "YOU WERE CAUGHT" :
                horrorStep == 0 ? "Find the exit. Save your light." :
                flashlight ? "Light pushes it back!" : "It's getting closer...";
        g.drawCenteredString(font, Component.literal(status), sx + 73, sy + 129, won ? 0xFFB9F4C7 : 0xFFFFD7E4);
        g.drawCenteredString(font, Component.literal("DOOR " + steps + " / 5   BAT " + battery + "%"), sx + 73, sy + 137, 0xFFBDAFCB);
        // Big tactile controls, styled like pixel buttons.
        drawHorrorButton(g, sx + 8, sy + 145, sx + 43, sy + 164, "◀");
        drawHorrorButton(g, sx + 47, sy + 145, sx + 98, sy + 164, flashlight ? "LIGHT ON" : "LIGHT");
        drawHorrorButton(g, sx + 102, sy + 145, sx + 137, sy + 164, "▶");
        if (gameOver || won) {
            g.fill(sx + 20, sy + 65, sx + 126, sy + 97, 0xF0000000);
            g.drawCenteredString(font, Component.literal(won ? "YOU ESCAPED!" : "CAUGHT"), sx + 73, sy + 70, won ? 0xFFB9F4C7 : 0xFFFF536D);
            g.drawCenteredString(font, Component.literal("RIGHT: play again"), sx + 73, sy + 82, WHITE);
            g.drawCenteredString(font, Component.literal("LEFT: return home"), sx + 73, sy + 90, 0xFFFFD9E6);
        }
    }

    private void drawHorrorButton(GuiGraphics g, int x1, int y1, int x2, int y2, String label) {
        g.fill(x1 + 2, y1 + 2, x2 + 2, y2 + 2, 0xFF08070D);
        g.fill(x1, y1, x2, y2, 0xFF8C4266);
        g.fill(x1 + 2, y1 + 2, x2 - 2, y2 - 2, 0xFF382238);
        g.drawCenteredString(font, Component.literal(label), (x1 + x2) / 2, y1 + 6, 0xFFFFD9E6);
    }

    private void drawAppIcon(GuiGraphics g, int x, int y, int color, String symbol) {
        g.fill(x + 2, y + 3, x + 26, y + 27, 0xFF28223F);
        g.fill(x, y, x + 24, y + 24, 0xFFFFEAF3);
        g.fill(x + 2, y + 2, x + 22, y + 22, color);
        g.drawCenteredString(font, Component.literal(symbol), x + 12, y + 7, 0xFF4B3A67);
    }

    private void drawApp(GuiGraphics g, int sx, int sy) {
        g.fill(sx + 2, sy + 2, sx + 144, sy + 172, 0xFFFFEAF3);
        g.fill(sx + 2, sy + 2, sx + 144, sy + 25, PINK);
        g.drawString(font, "‹  Pink Phone", sx + 8, sy + 10, WHITE, false);
        switch (app) {
            case "garden" -> {
                g.drawCenteredString(font, Component.literal("Little Garden"), sx + 73, sy + 42, PURPLE);
                g.fill(sx + 25, sy + 78, sx + 121, sy + 128, 0xFFB5D59B);
                g.fill(sx + 39, sy + 65, sx + 55, sy + 96, 0xFF548A68);
                g.fill(sx + 33, sy + 59, sx + 61, sy + 77, 0xFF75AE78);
                g.fill(sx + 83, sy + 73, sx + 101, sy + 103, 0xFF548A68);
                g.fill(sx + 77, sy + 64, sx + 108, sy + 83, 0xFF75AE78);
                g.drawCenteredString(font, Component.literal("grow something cute"), sx + 73, sy + 143, PURPLE);
            }
            case "music" -> {
                g.drawCenteredString(font, Component.literal("Now Playing"), sx + 73, sy + 42, PURPLE);
                g.fill(sx + 35, sy + 62, sx + 111, sy + 138, 0xFFD8C5EF);
                g.fill(sx + 51, sy + 79, sx + 95, sy + 121, 0xFFB58BCB);
                g.drawCenteredString(font, Component.literal("♫"), sx + 73, sy + 91, WHITE);
                g.drawCenteredString(font, Component.literal("pastel dreams"), sx + 73, sy + 145, PURPLE);
            }
            case "photos" -> {
                g.drawCenteredString(font, Component.literal("Photo Album"), sx + 73, sy + 42, PURPLE);
                int[] colors = {0xFFFFC5D9,0xFFB8D9E7,0xFFB9D79E,0xFFD5B8EB,0xFFFFDFA7,0xFFECA6C8};
                for (int i = 0; i < 6; i++) {
                    int x = sx + 13 + (i % 3) * 41, y = sy + 61 + (i / 3) * 42;
                    g.fill(x, y, x + 34, y + 34, 0xFFFFFFFF);
                    g.fill(x + 3, y + 3, x + 31, y + 31, colors[i]);
                    g.fill(x + 9, y + 11, x + 25, y + 14, 0xFFFFEDF5);
                }
            }
            case "notes" -> {
                g.drawCenteredString(font, Component.literal("Sweet Notes"), sx + 73, sy + 42, PURPLE);
                for (int i = 0; i < 4; i++) {
                    int y = sy + 62 + i * 24;
                    g.fill(sx + 12, y, sx + 134, y + 18, i % 2 == 0 ? 0xFFFFD5E6 : 0xFFE9DDF7);
                    g.drawString(font, new String[]{"remember the stars","feed the cat ♡","drink some water","be kind to yourself"}[i], sx + 16, y + 5, PURPLE, false);
                }
            }
            case "settings" -> {
                g.drawCenteredString(font, Component.literal("Settings"), sx + 73, sy + 42, PURPLE);
                String[] rows = {"Wallpaper: sunset","Case: strawberry milk","Theme: pastel","Notifications: ♡"};
                for (int i=0;i<rows.length;i++) {
                    int y=sy+63+i*25;
                    g.fill(sx+10,y,sx+136,y+19,0xFFFFD5E6);
                    g.drawString(font,rows[i],sx+15,y+6,PURPLE,false);
                }
            }
            default -> g.drawCenteredString(font, Component.literal("Coming soon ♡"), sx + 73, sy + 90, PURPLE);
        }
        g.fill(sx + 48, sy + 157, sx + 98, sy + 161, 0xFFB85F8B);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button != 0) return super.mouseClicked(mouseX, mouseY, button);
        mouseX = (mouseX - width / 2.0) / uiScale;
        mouseY = (mouseY - height / 2.0) / uiScale;
        int sx = left + 14, sy = top + 23;
        if (app.equals("battle")) {
            if (gameOver || won) { if(mouseY >= sy+153 && mouseX >= sx+115) { resetBattle(); return true; } }
            if(mouseY >= sy+153 && mouseY <= sy+171) {
                if(mouseX>=sx+5 && mouseX<sx+35) { playerX=Math.max(8,playerX-9); playerY=Math.max(34,playerY-3); }
                else if(mouseX>=sx+38 && mouseX<sx+79) fireBattleShot();
                else if(mouseX>=sx+82 && mouseX<sx+112) { if(ammo<12 && reserveAmmo>0 && reloadTicks==0) reloadTicks=18; }
                else if(mouseX>=sx+115) { app="home"; return true; }
                return true;
            }
            if(mouseY>=sy+25 && mouseY<=sy+142) { aimX=(int)mouseX-sx-5; aimY=(int)mouseY-sy-25+30; fireBattleShot(); return true; }
            return true;
        }
        if (app.equals("horror")) {
            if (mouseY >= sy + 145 && mouseY <= sy + 166) {
                if (mouseX >= sx + 8 && mouseX <= sx + 43) {
                    horrorStep = Math.max(0, horrorStep - 1);
                    steps = Math.max(0, steps - 1);
                    fear = Math.max(0, fear - 12);
                    if (won || gameOver) { app = "home"; return true; }
                    gameTicks = 0;
                } else if (mouseX >= sx + 47 && mouseX <= sx + 98) {
                    if (battery > 0) flashlight = !flashlight;
                    fear = Math.max(0, fear - (flashlight ? 8 : 3));
                    gameTicks = 0;
                } else if (mouseX >= sx + 102 && mouseX <= sx + 137) {
                    if (gameOver || won) {
                        horrorStep = 0; steps = 0; fear = 0; flashlight = false; gameTicks = 0; gameOver = false; won = false; battery = 100;
                    } else {
                        horrorStep++;
                        steps++;
                        fear = Math.min(100, fear + (flashlight ? 3 : 13));
                        if (horrorStep >= 5 && fear < 100) won = true;
                        if (fear >= 100) gameOver = true;
                        gameTicks = 0;
                    }
                }
                return true;
            }
            if (mouseY >= sy && mouseY <= sy + 23 && mouseX >= sx && mouseX <= sx + 70) { app = "home"; return true; }
            return true;
        }
        if (app.equals("home") && mouseX >= sx + 110 && mouseX <= sx + 142 && mouseY >= sy + 27 && mouseY <= sy + 64) {
            app = "battle"; resetBattle(); return true;
        }
        if (app.equals("home") && mouseX >= sx + 115 && mouseX <= sx + 142 && mouseY >= sy + 68 && mouseY <= sy + 101) {
            app = "settings"; return true;
        }
        if (app.equals("home") && mouseY >= sy + 128 && mouseY <= sy + 172) {
            if (mouseX >= sx + 4 && mouseX < sx + 38) app = "garden";
            else if (mouseX >= sx + 38 && mouseX < sx + 72) app = "music";
            else if (mouseX >= sx + 72 && mouseX < sx + 106) app = "photos";
            else if (mouseX >= sx + 106 && mouseX < sx + 144) app = "notes";
            else return super.mouseClicked(mouseX, mouseY, button);
            return true;
        }
        if (!app.equals("home") && mouseX >= sx && mouseX <= sx + 45 && mouseY >= sy && mouseY <= sy + 25) {
            app = "home";
            return true;
        }
        if (mouseX < left || mouseX > left + 180 || mouseY < top || mouseY > top + 230) {
            onClose();
            return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (app.equals("battle")) {
            if (keyCode==65 || keyCode==263) { playerX=Math.max(8,playerX-7); return true; }
            if (keyCode==68 || keyCode==262) { playerX=Math.min(128,playerX+7); return true; }
            if (keyCode==87 || keyCode==265) { playerY=Math.max(34,playerY-7); return true; }
            if (keyCode==83 || keyCode==264) { playerY=Math.min(140,playerY+7); return true; }
            if (keyCode==32 || keyCode==77) { fireBattleShot(); return true; }
            if (keyCode==82) { if(ammo<12 && reserveAmmo>0 && reloadTicks==0) reloadTicks=18; return true; }
            if (keyCode==27) { app="home"; return true; }
        }
        if (app.equals("horror")) {
            // A/Left retreats, D/Right advances, Space toggles the flashlight.
            if (keyCode == 263 || keyCode == 65) {
                horrorStep = Math.max(0, horrorStep - 1);
                steps = Math.max(0, steps - 1);
                fear = Math.max(0, fear - 12);
                if (won || gameOver) { app = "home"; return true; }
                gameTicks = 0;
                return true;
            }
            if (keyCode == 262 || keyCode == 68) {
                if (gameOver || won) {
                    horrorStep = 0; steps = 0; fear = 0; flashlight = false; gameOver = false; won = false; battery = 100;
                } else {
                    horrorStep++; steps++;
                    fear = Math.min(100, fear + (flashlight ? 3 : 13));
                    if (horrorStep >= 5 && fear < 100) won = true;
                    if (fear >= 100) gameOver = true;
                }
                gameTicks = 0;
                return true;
            }
            if (keyCode == 32) {
                if (battery > 0) flashlight = !flashlight;
                fear = Math.max(0, fear - (flashlight ? 8 : 3));
                gameTicks = 0;
                return true;
            }
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    private void fireBattleShot() {
        if(gameOver || won) { resetBattle(); return; }
        if(reloadTicks>0) return;
        if(ammo<=0) { if(reserveAmmo>0) reloadTicks=18; return; }
        ammo--; shotFlash=4;
        int target=-1, best=9999;
        for(int i=0;i<enemyAlive.length;i++) if(enemyAlive[i]) {
            int dx=Math.abs(enemyX[i]-aimX), dy=Math.abs((enemyY[i]-30)-aimY);
            int score=dx+dy;
            if(dx<=10 && dy<=10 && score<best) { best=score; target=i; }
        }
        if(target>=0) {
            enemyHp[target]--;
            if(enemyHp[target]<=0) { enemyAlive[target]=false; kills++; if(kills>=15) won=true; }
        }
    }

    private void resetBattle() {
        app="battle"; hp=100; ammo=12; reserveAmmo=48; kills=0; wave=1; shotFlash=0; hitFlash=0; reloadTicks=0; spawnTicks=0; gameOver=false; won=false; playerX=73; playerY=139;
        for(int i=0;i<enemyAlive.length;i++) enemyAlive[i]=false;
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
