package com.example.pinkphone;

import net.minecraft.client.Minecraft;

/** Client-only entry point. Kept separate so dedicated servers never load GUI classes. */
public final class PhoneClient {
    private PhoneClient() {}

    public static void openScreen() {
        Minecraft minecraft = Minecraft.getInstance();
        minecraft.setScreen(new PhoneScreen());
    }
}
