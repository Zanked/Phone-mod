package com.example.pinkphone;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;

public class PhoneScreen extends Screen {
    private String app = "home";
    private int page = 0;
    private int horrorStep = 0;
    private int fear = 0;
    private boolean flashlight = false;
    private static final ResourceLocation WALLPAPER = ResourceLocation.fromNamespaceAndPath("pinkphone", "textures/gui/wallpaper_sunset.png");
    private static final ResourceLocation HORROR_HALL = ResourceLocation.fromNamespaceAndPath("pinkphone", "textures/gui/horror_hall.png");
    private static final ResourceLocation HORROR_MONSTER = ResourceLocation.fromNamespaceAndPath("pinkphone", "textures/gui/horror_monster.png");

    private int left, top;
    private float uiScale = 1.0f;
    private int gameTicks = 0;
    private int steps = 0;
    private boolean gameOver = false;
    private static final int PINK = 0xFFF18BB9;
    private static final int LIGHT = 0xFFFFD5E6;
    private static final int PALE = 0xFFFFEEF5;
    private static final int DARK = 0xFF302943;
    private static final int PURPLE = 0xFF66558D;
    private static final int SHADOW = 0xFFB85F8B;
    private static final int WHITE = 0xFFFFF9FC;

    public PhoneScreen() {
        super(Component.literal("Pink Phone"));
    }

    @Override
    protected void init() {
        // Scale the complete interface to fit the available Minecraft GUI viewport.
        uiScale = Math.min(1.45f, Math.min((this.width - 24.0f) / 180.0f,
                (this.height - 18.0f) / 230.0f));
        uiScale = Math.max(0.55f, uiScale);
        left = -87;
        top = -112;
    }

    @Override
    public void tick() {
        super.tick();
        if (app.equals("horror") && !gameOver) {
            gameTicks++;
            if (gameTicks >= 100) {
                gameTicks = 0;
                if (horrorStep > 0 && !flashlight) fear = Math.min(100, fear + 3);
                if (fear >= 100) gameOver = true;
            }
        }
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        int actualMouseX = mouseX, actualMouseY = mouseY;
        // Soft dusk background stays in screen coordinates.
        g.fill(0, 0, width, height, 0xFF171C2B);
        for (int i = 0; i < 70; i++) {
            int x = Math.floorMod(i * 73 + 17, Math.max(1, width));
            int y = Math.floorMod(i * 41 + 9, Math.max(1, height));
            g.fill(x, y, x + (i % 5 == 0 ? 2 : 1), y + 1, i % 3 == 0 ? 0xFF766B9D : 0xFF414760);
        }
        g.pose().pushPose();
        g.pose().translate(width / 2.0f, height / 2.0f, 0);
        g.pose().scale(uiScale, uiScale, 1.0f);
        mouseX = (int) ((mouseX - width / 2.0f) / uiScale);
        mouseY = (int) ((mouseY - height / 2.0f) / uiScale);

        // A chunky, beveled pink phone frame.
        g.fill(left + 4, top + 5, left + 176, top + 228, 0xFF10131E);
        g.fill(left, top + 2, left + 174, top + 226, SHADOW);
        g.fill(left + 3, top, left + 171, top + 223, PINK);
        g.fill(left + 6, top + 3, left + 168, top + 220, LIGHT);
        g.fill(left + 9, top + 7, left + 165, top + 215, DARK);
        g.fill(left + 12, top + 10, left + 162, top + 212, 0xFF4C477A);

        // Bezel glints and screws.
        g.fill(left + 8, top + 9, left + 35, top + 11, WHITE);
        g.fill(left + 138, top + 9, left + 161, top + 11, 0xFFFFBFD8);
        g.fill(left + 7, top + 22, left + 10, top + 38, 0xFFFFBFD8);
        g.fill(left + 164, top + 45, left + 167, top + 70, SHADOW);
        g.fill(left + 74, top + 4, left + 101, top + 7, SHADOW);
        // Speaker and front camera.
        g.fill(left + 70, top + 13, left + 102, top + 16, 0xFF8D527C);
        g.fill(left + 111, top + 12, left + 117, top + 18, 0xFF624C79);
        g.fill(left + 113, top + 13, left + 115, top + 15, 0xFFB9D9E7);

        int sx = left + 14, sy = top + 23;
        g.fill(sx, sy, sx + 146, sy + 174, 0xFF25233E);

        if (app.equals("home")) {
            drawHome(g, sx, sy, mouseX, mouseY);
        } else if (app.equals("horror")) {
            drawHorror(g, sx, sy);
        } else {
            drawApp(g, sx, sy);
        }

        // Bottom bezel, tiny pink heart and navigation bar.
        g.fill(left + 70, top + 204, left + 104, top + 207, 0xFFB65D8A);
        g.fill(left + 84, top + 198, left + 88, top + 202, 0xFFFFD8E7);
        g.fill(left + 91, top + 198, left + 95, top + 202, 0xFFFFD8E7);
        g.fill(left + 87, top + 201, left + 93, top + 205, 0xFFFFD8E7);

        // Hardware side buttons, drawn outside the body.
        g.fill(left + 172, top + 47, left + 178, top + 71, SHADOW);
        g.fill(left + 172, top + 49, left + 176, top + 67, LIGHT);
        g.fill(left - 4, top + 61, left + 2, top + 82, SHADOW);
        g.fill(left - 3, top + 63, left + 1, top + 79, LIGHT);
        g.pose().popPose();
        super.render(g, actualMouseX, actualMouseY, partialTick);
    }

    private void drawHome(GuiGraphics g, int sx, int sy, int mouseX, int mouseY) {
        // Real PNG wallpaper asset bundled in the mod resources.
        g.blit(WALLPAPER, sx + 2, sy + 2, 0, 0, 142, 170, 584, 696);
        // Status row.
        g.fill(sx + 5, sy + 5, sx + 141, sy + 23, 0xFF45416F);
        g.drawString(font, "17:24", sx + 10, sy + 10, WHITE, false);
        g.drawString(font, "♥", sx + 112, sy + 9, 0xFFFFC4DF, false);
        g.drawString(font, "100%", sx + 119, sy + 9, WHITE, false);
        g.drawString(font, "Good evening!", sx + 9, sy + 27, WHITE, false);
        // Dock of app tiles over the wallpaper.
        drawAppIcon(g, sx + 5, sy + 132, 0xFFB8D89B, "✿");
        drawAppIcon(g, sx + 39, sy + 132, 0xFF9ED9EE, "♫");
        drawAppIcon(g, sx + 73, sy + 132, 0xFFEAC1E0, "♥");
        drawAppIcon(g, sx + 107, sy + 132, 0xFFC8B7F1, "⚙");
        g.drawString(font, "Garden", sx + 3, sy + 160, WHITE, false);
        g.drawString(font, "Music", sx + 40, sy + 160, WHITE, false);
        g.drawString(font, "Photos", sx + 71, sy + 160, WHITE, false);
        g.drawString(font, "Notes", sx + 108, sy + 160, WHITE, false);
        // Separate, clearly clickable game and settings shortcuts.
        g.fill(sx + 112, sy + 30, sx + 139, sy + 57, 0xFF211827);
        g.fill(sx + 114, sy + 32, sx + 137, sy + 55, 0xFF5A243E);
        g.fill(sx + 118, sy + 37, sx + 123, sy + 42, 0xFFFF4C70);
        g.fill(sx + 129, sy + 37, sx + 134, sy + 42, 0xFFFF4C70);
        g.drawString(font, "NIGHT", sx + 113, sy + 59, 0xFFFFD9E6, false);
        g.fill(sx + 118, sy + 70, sx + 139, sy + 91, 0xFFFFD5E6);
        g.drawCenteredString(font, Component.literal("⚙"), sx + 128, sy + 76, PURPLE);
        g.drawString(font, "SET", sx + 119, sy + 92, 0xFFFFD9E6, false);
    }

    private void drawHorror(GuiGraphics g, int sx, int sy) {
        // A tiny first-person survival-horror game rendered in the phone display.
        g.fill(sx + 2, sy + 2, sx + 144, sy + 172, 0xFF080912);
        g.fill(sx + 3, sy + 3, sx + 143, sy + 21, 0xFF211522);
        g.drawString(font, "NIGHT SHIFT", sx + 8, sy + 8, 0xFFFFB7C9, false);
        g.drawString(font, "FEAR " + fear + "%", sx + 91, sy + 8, 0xFFFF647E, false);
        g.fill(sx + 8, sy + 19, sx + 136, sy + 22, 0xFF4A263A);
        g.fill(sx + 8, sy + 19, sx + 8 + Math.min(128, fear * 128 / 100), sy + 22, 0xFFFF536D);
        // Use an actual pixel-art hallway PNG; perspective changes as player advances.
        g.blit(HORROR_HALL, sx + 4, sy + 25, 0, 0, 138, 99, 640, 480);
        // Threat approaches the player as the player moves deeper into the corridor.
        if (horrorStep > 1) {
            int size = Math.min(58, 16 + horrorStep * 7);
            int mx = sx + 75 - size / 2;
            int my = sy + 46 + Math.max(0, 28 - horrorStep * 3);
            g.blit(HORROR_MONSTER, mx, my, 0, 0, size, size, 192, 256);
        }
        // Flashlight cone / HUD vignette.
        if (flashlight) {
            g.fill(sx + 7, sy + 29, sx + 139, sy + 31, 0xFFFFE5A5);
            g.fill(sx + 10, sy + 32, sx + 136, sy + 34, 0x99FFE5A5);
        } else {
            g.fill(sx + 4, sy + 25, sx + 142, sy + 124, 0x18000000);
        }
        g.fill(sx + 4, sy + 126, sx + 142, sy + 170, 0xFF17111F);
        String status = gameOver || horrorStep >= 5 ? "YOU WERE CAUGHT" :
                horrorStep == 0 ? "Find the exit. Move carefully." :
                flashlight ? "Light slows the fear." : "Something is following...";
        g.drawCenteredString(font, Component.literal(status), sx + 73, sy + 129, 0xFFFFD7E4);
        g.drawCenteredString(font, Component.literal("STEP " + steps + " / 5"), sx + 73, sy + 137, 0xFFBDAFCB);
        // Big tactile controls, styled like pixel buttons.
        drawHorrorButton(g, sx + 8, sy + 145, sx + 43, sy + 164, "◀");
        drawHorrorButton(g, sx + 47, sy + 145, sx + 98, sy + 164, flashlight ? "LIGHT ON" : "LIGHT");
        drawHorrorButton(g, sx + 102, sy + 145, sx + 137, sy + 164, "▶");
        if (gameOver || horrorStep >= 5) {
            g.fill(sx + 20, sy + 65, sx + 126, sy + 97, 0xF0000000);
            g.drawCenteredString(font, Component.literal("CAUGHT"), sx + 73, sy + 70, 0xFFFF536D);
            g.drawCenteredString(font, Component.literal("tap RIGHT to retry"), sx + 73, sy + 82, WHITE);
            g.drawCenteredString(font, Component.literal("BACK returns home"), sx + 73, sy + 90, 0xFFFFD9E6);
        }
    }

    private void drawHorrorButton(GuiGraphics g, int x1, int y1, int x2, int y2, String label) {
        g.fill(x1 + 2, y1 + 2, x2 + 2, y2 + 2, 0xFF08070D);
        g.fill(x1, y1, x2, y2, 0xFF8C4266);
        g.fill(x1 + 2, y1 + 2, x2 - 2, y2 - 2, 0xFF382238);
        g.drawCenteredString(font, Component.literal(label), (x1 + x2) / 2, y1 + 6, 0xFFFFD9E6);
    }

    private void drawAppIcon(GuiGraphics g, int x, int y, int color, String symbol) {
        g.fill(x + 2, y + 3, x + 26, y + 27, 0xFF28223F);
        g.fill(x, y, x + 24, y + 24, 0xFFFFEAF3);
        g.fill(x + 2, y + 2, x + 22, y + 22, color);
        g.drawCenteredString(font, Component.literal(symbol), x + 12, y + 7, 0xFF4B3A67);
    }

    private void drawApp(GuiGraphics g, int sx, int sy) {
        g.fill(sx + 2, sy + 2, sx + 144, sy + 172, 0xFFFFEAF3);
        g.fill(sx + 2, sy + 2, sx + 144, sy + 25, PINK);
        g.drawString(font, "‹  Pink Phone", sx + 8, sy + 10, WHITE, false);
        switch (app) {
            case "garden" -> {
                g.drawCenteredString(font, Component.literal("Little Garden"), sx + 73, sy + 42, PURPLE);
                g.fill(sx + 25, sy + 78, sx + 121, sy + 128, 0xFFB5D59B);
                g.fill(sx + 39, sy + 65, sx + 55, sy + 96, 0xFF548A68);
                g.fill(sx + 33, sy + 59, sx + 61, sy + 77, 0xFF75AE78);
                g.fill(sx + 83, sy + 73, sx + 101, sy + 103, 0xFF548A68);
                g.fill(sx + 77, sy + 64, sx + 108, sy + 83, 0xFF75AE78);
                g.drawCenteredString(font, Component.literal("grow something cute"), sx + 73, sy + 143, PURPLE);
            }
            case "music" -> {
                g.drawCenteredString(font, Component.literal("Now Playing"), sx + 73, sy + 42, PURPLE);
                g.fill(sx + 35, sy + 62, sx + 111, sy + 138, 0xFFD8C5EF);
                g.fill(sx + 51, sy + 79, sx + 95, sy + 121, 0xFFB58BCB);
                g.drawCenteredString(font, Component.literal("♫"), sx + 73, sy + 91, WHITE);
                g.drawCenteredString(font, Component.literal("pastel dreams"), sx + 73, sy + 145, PURPLE);
            }
            case "photos" -> {
                g.drawCenteredString(font, Component.literal("Photo Album"), sx + 73, sy + 42, PURPLE);
                int[] colors = {0xFFFFC5D9,0xFFB8D9E7,0xFFB9D79E,0xFFD5B8EB,0xFFFFDFA7,0xFFECA6C8};
                for (int i = 0; i < 6; i++) {
                    int x = sx + 13 + (i % 3) * 41, y = sy + 61 + (i / 3) * 42;
                    g.fill(x, y, x + 34, y + 34, 0xFFFFFFFF);
                    g.fill(x + 3, y + 3, x + 31, y + 31, colors[i]);
                    g.fill(x + 9, y + 11, x + 25, y + 14, 0xFFFFEDF5);
                }
            }
            case "notes" -> {
                g.drawCenteredString(font, Component.literal("Sweet Notes"), sx + 73, sy + 42, PURPLE);
                for (int i = 0; i < 4; i++) {
                    int y = sy + 62 + i * 24;
                    g.fill(sx + 12, y, sx + 134, y + 18, i % 2 == 0 ? 0xFFFFD5E6 : 0xFFE9DDF7);
                    g.drawString(font, new String[]{"remember the stars","feed the cat ♡","drink some water","be kind to yourself"}[i], sx + 16, y + 5, PURPLE, false);
                }
            }
            case "settings" -> {
                g.drawCenteredString(font, Component.literal("Settings"), sx + 73, sy + 42, PURPLE);
                String[] rows = {"Wallpaper: sunset","Case: strawberry milk","Theme: pastel","Notifications: ♡"};
                for (int i=0;i<rows.length;i++) {
                    int y=sy+63+i*25;
                    g.fill(sx+10,y,sx+136,y+19,0xFFFFD5E6);
                    g.drawString(font,rows[i],sx+15,y+6,PURPLE,false);
                }
            }
            default -> g.drawCenteredString(font, Component.literal("Coming soon ♡"), sx + 73, sy + 90, PURPLE);
        }
        g.fill(sx + 48, sy + 157, sx + 98, sy + 161, 0xFFB85F8B);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button != 0) return super.mouseClicked(mouseX, mouseY, button);
        mouseX = (mouseX - width / 2.0) / uiScale;
        mouseY = (mouseY - height / 2.0) / uiScale;
        int sx = left + 14, sy = top + 23;
        if (app.equals("horror")) {
            if (mouseY >= sy + 145 && mouseY <= sy + 166) {
                if (mouseX >= sx + 8 && mouseX <= sx + 43) {
                    horrorStep = Math.max(0, horrorStep - 1);
                    steps = Math.max(0, steps - 1);
                    fear = Math.max(0, fear - 12);
                    gameTicks = 0;
                } else if (mouseX >= sx + 47 && mouseX <= sx + 98) {
                    flashlight = !flashlight;
                    fear = Math.max(0, fear - 5);
                    gameTicks = 0;
                } else if (mouseX >= sx + 102 && mouseX <= sx + 137) {
                    if (gameOver || horrorStep >= 5) {
                        horrorStep = 0; steps = 0; fear = 0; flashlight = false; gameTicks = 0; gameOver = false;
                    } else {
                        horrorStep++;
                        steps++;
                        fear = Math.min(100, fear + (flashlight ? 7 : 18));
                        if (horrorStep >= 5 || fear >= 100) gameOver = true;
                        gameTicks = 0;
                    }
                }
                return true;
            }
            if (mouseY >= sy && mouseY <= sy + 23 && mouseX >= sx && mouseX <= sx + 70) { app = "home"; return true; }
            return true;
        }
        if (app.equals("home") && mouseX >= sx + 110 && mouseX <= sx + 142 && mouseY >= sy + 27 && mouseY <= sy + 64) {
            app = "horror"; horrorStep = 0; steps = 0; fear = 0; flashlight = false; gameOver = false; gameTicks = 0; return true;
        }
        if (app.equals("home") && mouseX >= sx + 115 && mouseX <= sx + 142 && mouseY >= sy + 68 && mouseY <= sy + 101) {
            app = "settings"; return true;
        }
        if (app.equals("home") && mouseY >= sy + 128 && mouseY <= sy + 172) {
            if (mouseX >= sx + 4 && mouseX < sx + 38) app = "garden";
            else if (mouseX >= sx + 38 && mouseX < sx + 72) app = "music";
            else if (mouseX >= sx + 72 && mouseX < sx + 106) app = "photos";
            else if (mouseX >= sx + 106 && mouseX < sx + 144) app = "notes";
            else return super.mouseClicked(mouseX, mouseY, button);
            return true;
        }
        if (!app.equals("home") && mouseX >= sx && mouseX <= sx + 45 && mouseY >= sy && mouseY <= sy + 25) {
            app = "home";
            return true;
        }
        if (mouseX < left || mouseX > left + 180 || mouseY < top || mouseY > top + 230) {
            onClose();
            return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (app.equals("horror")) {
            // A/Left retreats, D/Right advances, Space toggles the flashlight.
            if (keyCode == 263 || keyCode == 65) {
                horrorStep = Math.max(0, horrorStep - 1);
                steps = Math.max(0, steps - 1);
                fear = Math.max(0, fear - 12);
                gameTicks = 0;
                return true;
            }
            if (keyCode == 262 || keyCode == 68) {
                if (gameOver || horrorStep >= 5) {
                    horrorStep = 0; steps = 0; fear = 0; flashlight = false; gameOver = false;
                } else {
                    horrorStep++; steps++;
                    fear = Math.min(100, fear + (flashlight ? 7 : 18));
                    if (horrorStep >= 5 || fear >= 100) gameOver = true;
                }
                gameTicks = 0;
                return true;
            }
            if (keyCode == 32) {
                flashlight = !flashlight;
                fear = Math.max(0, fear - 5);
                gameTicks = 0;
                return true;
            }
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
